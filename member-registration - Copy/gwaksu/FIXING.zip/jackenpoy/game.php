<?php
// rock.php / paper.php / scissors.php set $player before including this file
$choices = ['rock', 'paper', 'scissors'];
$beats   = ['rock' => 'scissors', 'paper' => 'rock', 'scissors' => 'paper'];
$secure  = !empty($_SERVER['HTTPS']);

/* ---------- Cookie consent ---------- */
function setConsent($value, $secure) {
    setcookie('jkp_consent', $value, [
        'expires'  => time() + 60 * 60 * 24 * 365,
        'path'     => '/',
        'secure'   => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
}

if (isset($_POST['consent'])) {
    if ($_POST['consent'] === 'accept') {
        setConsent('accepted', $secure);
    } elseif ($_POST['consent'] === 'reject') {
        setConsent('rejected', $secure);
        // Remove any existing session cookie + data
        if (isset($_COOKIE[session_name()])) {
            session_start();
            $_SESSION = [];
            session_destroy();
            setcookie(session_name(), '', time() - 3600, '/');
        }
    } elseif ($_POST['consent'] === 'change') {
        setcookie('jkp_consent', '', time() - 3600, '/');
    }
    header('Location: index.php');
    exit;
}

$consent  = $_COOKIE['jkp_consent'] ?? null;   // 'accepted' | 'rejected' | null
$accepted = ($consent === 'accepted');

/* ---------- Session cookie only if accepted ---------- */
if ($accepted) {
    session_set_cookie_params([
        'lifetime' => 0,              // session cookie: gone when browser closes
        'path'     => '/',
        'secure'   => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
    if (!isset($_SESSION['score'])) {
        $_SESSION['score'] = ['win' => 0, 'lose' => 0, 'draw' => 0];
    }
}

/* ---------- Reset ---------- */
if ($accepted && isset($_POST['reset'])) {
    unset($_SESSION['score'], $_SESSION['last']);
    header('Location: index.php');
    exit;
}

/* ---------- Play ---------- */
$last = null;
if (isset($player) && in_array($player, $choices, true)) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {   // opened the file directly
        header('Location: index.php');
        exit;
    }
    $computer = $choices[array_rand($choices)];
    $result   = ($player === $computer) ? 'draw' : ($beats[$player] === $computer ? 'win' : 'lose');
    $last     = compact('player', 'computer', 'result');

    if ($accepted) {
        $_SESSION['score'][$result]++;
        $_SESSION['last'] = $last;
        header('Location: index.php');
        exit;
    }
    // Rejected / undecided: show the result once, nothing is stored
}

if ($accepted) {
    $last  = $_SESSION['last'] ?? null;
    $score = $_SESSION['score'];
}

$messages = ['win' => 'You Win! 🎉', 'lose' => 'You Lose! 😢', 'draw' => "It's a Draw! 🤝"];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Jack en Poy</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="game">
    <h1>Jack en Poy</h1>

    <?php if ($accepted): ?>
    <div class="scoreboard">
        <div class="win">Wins<span><?= $score['win'] ?></span></div>
        <div class="draw">Draws<span><?= $score['draw'] ?></span></div>
        <div class="lose">Losses<span><?= $score['lose'] ?></span></div>
    </div>
    <?php else: ?>
        <p class="note">Score tracking is off. Accept cookies to save your score.</p>
    <?php endif; ?>

    <?php if ($last): ?>
        <div class="battle">
            <div class="side">
                <p>You</p>
                <img src="images/<?= $last['player'] ?>.png" alt="<?= $last['player'] ?>">
            </div>
            <div class="vs">VS</div>
            <div class="side">
                <p>Computer</p>
                <img src="images/<?= $last['computer'] ?>.png" alt="<?= $last['computer'] ?>">
            </div>
        </div>
        <h2 class="result <?= $last['result'] ?>"><?= $messages[$last['result']] ?></h2>
    <?php else: ?>
        <p class="hint">Pick your move!</p>
    <?php endif; ?>

    <div class="choices">
        <?php foreach ($choices as $c): ?>
            <form method="post" action="<?= $c ?>.php">
                <button type="submit">
                    <img src="images/<?= $c ?>.png" alt="<?= $c ?>">
                    <span><?= ucfirst($c) ?></span>
                </button>
            </form>
        <?php endforeach; ?>
    </div>

    <div class="footer-actions">
        <?php if ($accepted): ?>
            <form method="post" action="index.php"><button type="submit" name="reset" class="reset">Reset Score</button></form>
        <?php endif; ?>
        <?php if ($consent): ?>
            <form method="post" action="index.php"><button type="submit" name="consent" value="change" class="link-btn">Change cookie choice</button></form>
        <?php endif; ?>
    </div>
</div>

<?php if ($consent === null): ?>
<div class="cookie-banner">
    <p>🍪 This game uses a session cookie to remember your score. It is deleted when you close your browser.</p>
    <form method="post" action="index.php">
        <button type="submit" name="consent" value="accept" class="btn accept">Accept</button>
        <button type="submit" name="consent" value="reject" class="btn reject">Reject</button>
    </form>
</div>
<?php endif; ?>
</body>
</html>
