<?php
$player = 'paper';
require __DIR__ . '/game.php';
