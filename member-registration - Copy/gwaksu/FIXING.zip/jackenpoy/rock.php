<?php
$player = 'rock';
require __DIR__ . '/game.php';
