<?php
$player = 'scissors';
require __DIR__ . '/game.php';
